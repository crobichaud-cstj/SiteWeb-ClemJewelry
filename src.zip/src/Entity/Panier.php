<?php

namespace App\Entity;
class Panier
{

    private $achats = [];

    public function delete($index){
        if(array_key_exists($index, $this->achats)){
            unset($this->achats[$index]);
        }
    }

    public function add(Achat $achat) {

        $achatExist = $this->checkIfExist($achat);

        if($achatExist == "false"){
            $this->achats[] = $achat;
        }
        else{
            $quantite = $this->achats[$achatExist]->getQuantite();
            $this->achats[$achatExist]->setQuantite($quantite + 1);
        }
    }


    public function update($newAchats){

        if(count($this->achats) > 0){
            $achatQTN = $newAchats["inputQTN"];
            foreach($this->achats as $key => $achat){


                if($achat->getQuantite() <= 0){
                    $this->delete($key);
                }else{
                    $newQTN = $achatQTN[$key];
                    $achat->update($newQTN);
                }

               
            }

        }
        

    }
    private function checkIfExist($achat){

        $i = 0;

        foreach ($this->achats as $achatOfList) {
            $i++;
            if($achatOfList->getProduit()->getIdProduit() == $achat->getProduit()->getIdProduit()){
                return $i -1;
            }
        }
        return "false";

    }

    

    public function getAchats(){
        return $this->achats;
    }

    public function getProduits(){
        return $this->achats;
    }

}
