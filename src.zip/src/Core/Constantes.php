<?php

namespace App\Core;

class Constantes
{

    public const TVQ = 0.09975;
    public const TPS = 0.05;

    public const SHIPPING = 5.99;

    
}